// import {ORDER_FORM} from "./order-submit.js";
// import {order} from "./order-submit.js";
//
// const BTN_RESET = ORDER_FORM.querySelector('.order-form__btn--reset');
//
// BTN_RESET.addEventListener('click', () => {
//     order = {};
// })