export function createLabel({value, type, name, attribute}) {
    const label = document.createElement('label');
    label.textContent = value;
// label.for = `${name} ${value}`;
    label.setAttribute('for', `${name} ${value}`);

    return label;
}