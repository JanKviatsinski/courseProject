import {showModal} from "./show-modal.js";
// import {addProductsToOrder} from "./add-data-to-order.js";
import {searchNameInOrders} from "./search-name-in-orders.js";
import {formValidation} from "./form-validation.js";
import {readingAllOrders} from "./reading-all-orders.js";
import {postOrder} from "./post-order.js";

export const URL_ORDER = 'https://course-project-kviatsinski-default-rtdb.firebaseio.com/orders.json';

export const ORDER_FORM = document.querySelector('#order-form');
export const MODAL_ORDER_FORM = document.querySelector('.order-form__modal');
export const PARAGRAPH_MODAL_ORDER = MODAL_ORDER_FORM.querySelector('.order-form__modal-paragraph')
export let order = {};
export const USER_NAME = ORDER_FORM.querySelector('.order-form__user-name');
export const USER_NOTE = ORDER_FORM.querySelector('textarea');


ORDER_FORM.addEventListener('submit', async (evt) => {
        evt.preventDefault();

        let [nameIsChecked, productIsChecked] = formValidation(order);


    if (!productIsChecked) {
        showModal('Вы не выбрали ни одного продукта');
        return false;
    }

    if (!nameIsChecked) {
        showModal('Нужно обязательно ввести имя.');
        return false;
    }

        const ORDERS = await readingAllOrders();

        if (ORDERS === null) {
            postOrder(order, URL_ORDER);
            return false;/*nado li?*/
        }

        const NAME_IS_IN_ORDER = await searchNameInOrders(USER_NAME,ORDERS);

        NAME_IS_IN_ORDER ? showModal('Заказ с таким именем уже есть. Используйте пожалуста' +
            ' другое имя.') : postOrder(order, URL_ORDER);


    }
)

function delet() {
    fetch(URL_ORDER, {method: 'DELETE',})
}

// delet ();
const BTN_RESET = ORDER_FORM.querySelector('.order-form__btn--reset');

BTN_RESET.addEventListener('click', () => {
    order = {};
})






