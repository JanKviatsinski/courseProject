export function createInput({value, type, name, attribute}){
    const input = document.createElement('input');
    input.type = type;
    input.name = name;
    input.value = value;
    input.id = `${name} ${value}`;
    input.setAttribute('data-category', attribute);

    return input;
}